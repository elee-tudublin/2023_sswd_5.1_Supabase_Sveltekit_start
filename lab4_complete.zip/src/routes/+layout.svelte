<nav class="navbar navbar-expand-sm navbar-dark bg-dark static-top">
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <a class="nav-link" href="/">Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/about">About</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/contact">Contact</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/products">Products</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/users">Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/nasa">NASA APOD</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/runningtotal">Total</a>
        </li>
    </ul>
</nav>
<style>
	nav a {
		color: yellow;
	}
</style>

<slot />