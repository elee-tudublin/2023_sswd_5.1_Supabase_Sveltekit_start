<script>
    export let data;
</script>
<div class="m-5">
    <h1>Welcome to the About Page <span class="name">{data.name}</span></h1>
</div>

<style>
    .name {
        color: red;
    }

</style>